package Seguridad;


import Utilidades.Datos;
import javax.swing.JOptionPane;

public class Ranking {
   static String ranp[][] = new String [30] [11];
  public static void setCargaJugadores (String docjugadores[]){
      for (int i = 0; i < 30; i++) {
          ranp [i][0]= docjugadores[i];
          
              
      }
}
  public static String getResultados(){
  String tabla="<html><Body><table>";
  
      for (int i = 0; i < 30; i++) {
          tabla+= "<tr>";
          for (int j = 0; j < 11; j++) {
              tabla+="<td>"+ranp[i][j]+"</td>";
          }
       tabla+= "</tr>"; 
      }
  return tabla;
  }
  public static void setPuntosranking(String usuario, int pos,int punto){
      Datos.setContador(punto);
      punto=Datos.getContador();
      for (int i = 0; i < 30; i++) {
          if ( ranp[i][0].equals(usuario)) {
             ranp[pos][0]= ""+punto;
             
             i=30;
              
              
          }
          for (int j = 0; j < 11; j++) {
             
          }
     
      }
  
  } 
 
  public static void main (String args[]){
  Usuario.setCargarInicial();
  setCargaJugadores(Usuario.getDocumento());
      JOptionPane.showMessageDialog(null, getResultados());
  }
}

