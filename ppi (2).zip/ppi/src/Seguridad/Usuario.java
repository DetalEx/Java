
package Seguridad;

import java.util.Scanner;


public class Usuario {
    static String documento[]= new String[30];
    static String nombre[]= new String[30];
    static String clave[]= new String[30];
    static String nivel[]= new String[30];
    public static void setCargarInicial(){
    for( int i = 0 ;i < documento.length ;i++){
    documento[i]="1000"+i;
    nombre[i]="matematico"+i;
    clave[i]="yopuedo"+i;
    nivel[i]="Uno";
    }
}
    public static String getInicio(String id, String passw){
    String resp="";
        for (int i = 0; i < nombre.length; i++) {
            if((nombre[i].equals(id) && (clave[i].equals(passw)))){
            resp="Bienvenido a FacSimplify "+nombre[i];
            i=nombre.length;
            }
        }
        return resp;
    }
        public static String getUsu(){
    String resp="";
    String usu="Rita1";
        for (int i = 0; i < nombre.length; i++) {
            if(nombre[i].equals(usu)){
                resp=""+usu;
                    }
        }
        return resp;
}        
        public static String getClave(){
    String resp="";
String passw="zapato1";
        for (int i = 0; i < clave.length; i++) {
            if(clave[i].equals(passw)){
                resp=""+passw;
                    }
        }
        return resp;
}        
    
    public static String[] getDocumento() {
        return documento;
    }
    
    
}
