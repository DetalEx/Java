package Arreglos;

import java.util.Scanner;

public class Primero {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //System.out.println("DIigte el tamaño del vector");
        int a = sc.nextInt();
        int i;
        String anny[] = {"Anny", "Valeria", "Melisa fea", "KK"};

        for (i = 0; i < anny.length; i++) {
            System.out.println("El vector es:" + anny[i]);
        }

        while (i < anny.length) {
            System.out.println("La lista de nombres es:" + anny[i]);
            i++;
        }
        i = 0;
        do {
            i++;
            try {
                System.out.println("Nombre listado [" + i + "];" + anny[i]);
            } catch (Exception e) {
                System.out.println("No hay");
            }

        } while (i < anny.length);

    }
}
