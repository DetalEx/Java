package Arreglos;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Tercero {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese numero de empleados");
        int a = sc.nextInt();

        System.out.println("");
        double valorh;
        String trabajador[] = new String[a];
        double valor[] = new double[a];
        double hora[] = new double[a];
        double salario[] = new double[a];
        String nombre = "";
        for (int i = 0; i < trabajador.length; i++) {
            System.out.println("Ingrese empleado en posicion [" + i + "]");

            trabajador[i] = sc.next();

            System.out.println("Valor de horas trabajadas para " + trabajador[i]);
            valor[i] = sc.nextDouble();

            System.out.println("horas trabajadas para" + trabajador[i]);
            hora[i] = sc.nextDouble();

            salario[i] = hora[i] * valor[i];
        }
        for (int j = 0; j < trabajador.length; j++) {
            System.out.println(trabajador[j] + "$" + salario[j] + "= $" + valor[j] + "" + hora[j]);
        }
        String tabla = "<html><body><table><tr><td>Nro.</td><td>Nombre</td><td>Horas</td><td>valor</td><td>Salario</>";
        for (int j = 0; j < trabajador.length; j++) {
            System.out.println(trabajador[j] + "$" + salario[j] + "= $" + valor[j] + "" + hora[j]);
            tabla += "<tr><td>" + j + "</td><td>" + trabajador[j] + "</td><td>" + hora[j] + "</td><td>" + valor[j] + "</td><td>" + salario[j] + "</td></tr>";
        }
        tabla += "</table></body></html>";
        JOptionPane.showMessageDialog(null, tabla);
    }

}
