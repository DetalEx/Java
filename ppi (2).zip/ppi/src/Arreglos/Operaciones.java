package Arreglos;

import java.util.Scanner;

public class Operaciones {

    static String[] datos = new String[1000];

    public static void setCargardatos() {
        for (int i = 0; i < datos.length; i++) {
            datos[i] = "dato" + i;
        }

    }

    public static void setImprimirDatos() {
        for (int i = 0; i < datos.length; i++) {
            System.out.println("[" + i + "]" + datos[i]);
        }

    }

    public static String getBuscarPorPosicion(int posicion) {
        String respuesta = "";
        //Scanner sc=new Scanner(System.in);
        //int posicion=sc.nextInt();
        respuesta = "[" + posicion + "]" + datos[posicion];
        return respuesta;

    }

    public static String getBuscarPorDato(String dato) {
        String resp = "";
        for (int i = 0; i < datos.length; i++) {
            if (datos[i].equals(dato)) {
                resp = "[" + i + "]=" + datos[i];
                i = datos.length;

            }
        }
        return resp;
    }

    public static void setEditarDato(String dat, String nuev) {
        for (int i = 0; i < datos.length; i++) {
            if (datos[i].equals(dat)) {
                datos[i] = nuev;
                i = datos.length;
            }
        }

    }

    public static String getContador(String valor) {
        String res = "";
        int a = 0;
        for (int i = 0; i < datos.length; i++) {
            if (datos[i].equals(valor)) {
                a++;
            }
        }
        res = "Se encontraron " + a + " " + valor;
        return res;
    }

    public static void setBorrar(String aborrar) {
        for (int i = 0; i < datos.length; i++) {
            if (datos[i].equals(aborrar)) {
                datos[i] = "*";
            }
        }
    }

    public static void setBorrados() {
        for (int i = 0; i < datos.length; i++) {
            if (datos[i].equals("*")) {
                System.out.println("Los datos borrados son: [" + i + "]");
            }
        }
    }
public static void setExistentes(){
    for (int i = 0; i < datos.length; i++) {
        if(!datos[i].equals("*")){
            System.out.println("Los datos existentes son: [" +i+"]");
        }
    }
}
    public static void main(String[] args) {
        setCargardatos();
        //     setImprimirDatos();
        /* Scanner sc = new Scanner(System.in);
        System.out.println("Digite la posicion");
        int posicion = sc.nextInt();
        System.out.println(getBuscarPorPosicion(posicion));
        
        System.out.println("Digite el dato para buscar su posicion");
        String pos = sc.next();
        System.out.println(getBuscarPorDato(pos));
        setEditarDato("dato999", "culitos");
        setEditarDato("dato998", "culitos");
        setEditarDato("dato0", "culitos");
        setEditarDato("dato1", "culitos");
        setEditarDato("dato50", "culitos");
        setEditarDato("dato2", "karen fea");
        setEditarDato("dato3", "karen fea");
//        setImprimirDatos();
        System.out.println(getContador("culitos"));
        System.out.println(getContador("karen fea"));*/
        setImprimirDatos();
        setBorrar("dato0");
        setBorrar("dato1");
        setBorrar("dato2");
        setBorrar("dato3");
        setImprimirDatos();
        setBorrados();
        setExistentes();

    }
}
