
package Arreglos;


public class Segundo {
    public static void main(String[] args) {
        int i = 1;
        int j= 1;
        for (int k = 100; k > j; k--) {
            System.out.println("k="+k);
            for (int l = 100; l > k; l--) {
                System.out.print("*");
            }
            
          
        }
    }
}
