                                     
package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Constructor;
import java.nio.file.Files;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.WindowConstants;

public class Ventana6 extends JFrame implements ActionListener {
String ruta = "/imagenes/";
    JRadioButton rdbt1, rdbt2,
            rdbt3, rdbt4;
    JButton btnok;
    JLabel lblpregunta,lblpregunta1;
    ButtonGroup grupop1;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana6(String titulo, int ancho, int alto) {
         this.setResizable(false);
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
       ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);

        lblpregunta = new JLabel("La siguiente estructura que");
        lblpregunta.setFont(letra2);
                lblpregunta1 = new JLabel("corresponde a 9x^2+24x+16 es:");
               lblpregunta1.setFont(letra2);

         

        rdbt1 = new JRadioButton("Trinomio de la forma ax^2+bx+c");
        rdbt1.setFont(letra);
        rdbt2 = new JRadioButton("Factor común");
       rdbt2.setFont(letra);
        rdbt3 = new JRadioButton("Trinomio cuadrado perfecto");
        rdbt3.setFont(letra);
        rdbt4 = new JRadioButton("Ninguna de las anteriores");
        rdbt4.setFont(letra);
        grupop1 = new ButtonGroup();
        
        btnok = new JButton("Ok");
        btnok.setFont(letra);
        

        lblpregunta.setBounds(10, 20, 450, 30);
        lblpregunta1.setBounds(10, 50, 450, 30);
        rdbt1.setBounds(30, 90, 450, 30);
        rdbt2.setBounds(30, 130, 450, 30);
        rdbt3.setBounds(30, 170, 450, 30);
        rdbt4.setBounds(30, 210, 450, 30);
        btnok.setBounds(200, 250, 80, 30);
        

        grupop1.add(rdbt1);
        grupop1.add(rdbt2);
        grupop1.add(rdbt3);
        grupop1.add(rdbt4);
       

        add(lblpregunta);
        add(lblpregunta1);
        add(rdbt1);
        add(rdbt2);
        add(rdbt3);
        add(rdbt4);
        add(btnok);
        btnok.addActionListener(this);
        

        setVisible(true);

    }

    public void setValidar() {
        if (rdbt1.isSelected()) {
            Datos.setContador(10);
             Puntuacion.preg6=10;
             
            btnok.setVisible(false);
        }else{
        btnok.setVisible(false);
            Datos.setErrores(10);
             Puntuacion.preg6=0;

        }
    }

    public static void main(String[] args) {
        new Ventana6("nivel 2, pregunta 1", 500, 400);

    }

    @Override
    public void actionPerformed(ActionEvent boton) {
        if (boton.getSource() == btnok) {
            setValidar();
            dispose();
            new Ventana7("NIvel  2, pregunta 2. ", 500, 400);

        }

    }
}