/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package NIVEL21;

import Utilidades.Datos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

public class Puntuacion extends JFrame implements ActionListener {
    static int preg1,preg2,preg3,preg4,preg5,preg6,preg7,preg8,preg9,preg10;
    JButton btnok;
    JLabel lblpregunta, prg1, prg2, prg3, prg4, prg5, prg6, prg7, prg8, prg9, prg10,total1,total2;

    public Puntuacion(String titulo, int ancho, int alto) {
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);

        this.getContentPane().setBackground(Color.LIGHT_GRAY) ;




        lblpregunta = new JLabel(" Tus puntuaciones son: ");
        Font fuente = new Font("Times New Roman", 1, 20);
        lblpregunta.setFont(fuente);
       prg1 = new JLabel("Pregunta 1: "+preg1);
        prg2 = new JLabel("Pregunta 2: "+preg2);
        prg3 = new JLabel("Pregunta 3: "+preg3);
        prg4 = new JLabel("Pregunta 4: "+preg4);
        prg5 = new JLabel("Pregunta 5: "+preg5);
        prg6 = new JLabel("Pregunta 6: "+preg6);
        prg7 = new JLabel("Pregunta 7: "+preg7);
        prg8 = new JLabel("Pregunta 8: "+preg8);
        prg9 = new JLabel("Pregunta 9: "+preg9);
        prg10 = new JLabel("Pregunta 10: "+preg10);
        total1=new JLabel("Total aciertos: "+Datos.getContador());
  total2=new JLabel("Total errores: "+Datos.getErrores());
        btnok = new JButton("Menu");
        lblpregunta.setBounds(10, 20, 600, 20);

        btnok.setBounds(100, 63, 100, 30);
        btnok.setFont(fuente);
        add(btnok);
        add(lblpregunta);
        prg1.setBounds(10, 120, 170, 25);
        prg2.setBounds(10, 160, 170, 25);
        prg3.setBounds(10, 200, 170, 25);
        prg4.setBounds(10, 240, 170, 25);
        prg5.setBounds(10, 280, 170, 25);
        prg6.setBounds(10, 320, 170, 25);
        prg7.setBounds(10, 360, 170, 25);
        prg8.setBounds(10, 400, 170, 25);
        prg9.setBounds(10, 440, 170, 25);
        prg10.setBounds(10, 480, 170, 25);
         total1.setBounds(200, 120, 200, 30);
        total2.setBounds(360, 120, 200, 30);
       total1.setFont(fuente);
       total2.setFont(fuente);
        prg1.setFont(fuente);
        prg2.setFont(fuente);
        prg4.setFont(fuente);
        prg3.setFont(fuente);
        prg5.setFont(fuente);
        prg6.setFont(fuente);
        prg7.setFont(fuente);
        prg8.setFont(fuente);
        prg9.setFont(fuente);
        prg10.setFont(fuente);
        
        
        
        
        
        
        btnok.addActionListener(this);
        add(prg1);
        add(prg2);

        add(prg3);
        add(prg4);
        add(prg5);
        add(prg6);

        add(prg7);
        add(prg8);
        add(prg9);
        add(prg10);
        add(total1);
        add(total2);
        setVisible(true);

    }
    public static void Llamarpuntos(int punto){
    Datos.setContador(punto);
    Datos.getContador();
       
    }

    public static void main(String[] args) {
        new Puntuacion("Puntuaciones ", 600, 600);

    }

    @Override
    public void actionPerformed(ActionEvent boton) {
        if (boton.getSource() == btnok) {
            new JMenup("Menú");
        }
        
    }
}
