package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Ventana1 extends JFrame implements ActionListener {

    String ruta = "/imagenes/";
    JCheckBox ckop1, ckop2, ckop3, ckop4;
    JLabel lblpregunta, lbop2, lbop3, fondo, lblpregunta1;
    JButton btnok;
    int contador = 0;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana1(String titulo, int ancho, int alto) {
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
 this.setResizable(false);
        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);
     

        lblpregunta = new JLabel("¿Cuáles de las siguientes operaciones");
        lblpregunta.setFont(letra2);
        lblpregunta1 = new JLabel("el factor común es 2x?");
        lblpregunta1.setFont(letra2);
        ckop1 = new JCheckBox("6x+4x");
        ckop1.setFont(letra);
        ckop2 = new JCheckBox("7x+2");
        ckop2.setFont(letra);
        ckop3 = new JCheckBox("80/2x-12x");
        ckop3.setFont(letra);
        ckop4 = new JCheckBox("4x+9");
        ckop4.setFont(letra);
        btnok = new JButton("Ok");
        btnok.setFont(letra);

        lblpregunta.setBounds(10, 16, 500, 25);
        lblpregunta1.setBounds(26, 57, 500, 25);
        ckop1.setBounds(95, 100, 135, 30);
        ckop2.setBounds(95, 140, 135, 30);
        ckop3.setBounds(95, 180, 135, 30);
        ckop4.setBounds(95, 220, 135, 30);

        btnok.setBounds(122, 260, 80, 30);

        btnok.addActionListener(this);

        

        add(lblpregunta);
        add(lblpregunta1);
        add(ckop1);
        add(ckop2);
        add(ckop3);
        add(ckop4);
        add(btnok);

        setVisible(true);

    }

    public void setValidar() {
        if ((ckop1.isSelected()) && (ckop3.isSelected())
                && (!ckop2.isSelected()) && (!ckop4.isSelected())) {

            btnok.setVisible(false);
            Datos.setContador(10);
            Puntuacion.preg1 = 10;
        } else {

            btnok.setVisible(false);
            Datos.setErrores(10);
            Puntuacion.preg1 = 0;
        }

    }

    public static void main(String[] args) {
        new Ventana1("NIvel  1, pregunta 1", 500, 400);

    }

    @Override
    public void actionPerformed(ActionEvent boton) {
        if (boton.getSource() == btnok) {
                setValidar();
                dispose();
                new Ventana2("NIvel 1 , pregunta 2", 550, 500);
            
        }
    }

   
}
