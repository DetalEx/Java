package NIVEL21;

import static Seguridad.Usuario.getInicio;
import static Seguridad.Usuario.setCargarInicial;
import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Registros extends JFrame implements ActionListener {

    JLabel usu = new JLabel("USUARIO");
    JLabel clave = new JLabel("CONTRASEÑA");
    JButton aceptar = new JButton("ACEPTAR");
    JButton siguiente = new JButton("SIGUIENTE");
    JButton cancelar = new JButton("CANCELAR");
    JTextField cdr1 = new JTextField();
    JTextField cdr2 = new JTextField();
    String ruta = "/imagenes/";

    public Registros(String Titulo, int ancho, int alto) {
        setLayout(null); //evitar distribuciones automaticas
        setTitle(Titulo);//titulo
        setSize(ancho, alto);//tamaño formularios
        setLocationRelativeTo(this);//centrado automatico
        this.getContentPane().setBackground(Color.LIGHT_GRAY);

        usu.setBounds(20, 20, 100, 30);
        clave.setBounds(20, 70, 100, 30);
        cdr1.setBounds(140, 20, 100, 30);
        cdr2.setBounds(140, 70, 100, 30);
        aceptar.setBounds(40, 120, 100, 30);
        cancelar.setBounds(160, 120, 100, 30);
        siguiente.setBounds(100, 170, 100, 30);
        add(usu);
        add(clave);
        add(cdr1);
        add(cdr2);
        add(cancelar);
        add(aceptar);

        setVisible(true);
JOptionPane.showMessageDialog(null, "Usuario: matematicoN \n"
        + "Contraseña: yopuedoN \n"
        + "N es un numero que quieras");

        aceptar.addActionListener(this);
        cancelar.addActionListener(this);

        siguiente.addActionListener(this);
        siguiente.setVisible(false);

    }

    public void setValidar(String id, String clave) {
        setCargarInicial();
        String res = getInicio(id, clave);

        if (res.length() == 0) {
            JOptionPane.showMessageDialog(null, "Datos incorrectos");
        } else {
            JOptionPane.showMessageDialog(null, res);
        }

    }

    public static void main(String[] args) {
        new Registros("Iniciar",320,280);

    }

    @Override
    
    public void actionPerformed(ActionEvent e) {

        String a = cdr1.getText();
        String b = cdr2.getText();

        if (e.getSource() == aceptar) {
            setValidar(a, b);
            siguiente.setVisible(true);
            add(siguiente);

        }
        if (e.getSource() == cancelar) {
            cdr1.setText("");
            cdr2.setText("");
        }
        if (e.getSource() == siguiente) {
            dispose();
            new JMenup("Menú");
        }
    }

}
