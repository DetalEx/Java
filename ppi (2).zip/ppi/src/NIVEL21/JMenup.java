package NIVEL21;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Font; 


public class JMenup extends JFrame implements ActionListener {

    String ruta = "/imagenes/";
    ImageIcon usuario = new ImageIcon(getClass().getResource(ruta + "usuario.png"));
    ImageIcon juego = new ImageIcon(getClass().getResource(ruta + "juego.png"));
    ImageIcon puntuaciones = new ImageIcon(getClass().getResource(ruta + "progreso.png"));
    ImageIcon ayuda = new ImageIcon(getClass().getResource(ruta + "ayuda.png"));
    ImageIcon acerca = new ImageIcon(getClass().getResource(ruta + "librito.png"));
    JMenuBar barra = new JMenuBar();
    JMenu archivo = new JMenu("Archivo");
   
    JMenu ayudaa = new JMenu("Ayuda");
    JMenuItem submenu, subpuntuaciones, subniveles, subacerca, subayuda, nivel1, nivel2,subjuego;
    JButton btncomen;
Font letra = new Font("Times New Roman", 1, 20);
    public JMenup(String title) {
       
        
        setTitle(title);

        setLocation(350, 150);
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "Facsimplify.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource(ruta + "usuario.png")).getImage());
        btncomen = new JButton("Comenzar");
        JLabel fondo = new JLabel(img);
        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 25, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);
        setLayout(null);
        ayudaa.setMnemonic('a');
        archivo.setMnemonic('r');
        
        setJMenuBar(barra);
        barra.add(archivo);
     
        barra.add(ayudaa);
         
      

       
        subpuntuaciones = new JMenuItem("Puntuaciones", puntuaciones);
        archivo.add(subpuntuaciones);
        subjuego = new JMenuItem("Juego", juego);
        archivo.add(subjuego);
        subayuda = new JMenuItem("Ayuda", ayuda);
        ayudaa.add(subayuda);
        subacerca = new JMenuItem("Acerca", acerca);
        ayudaa.add(subacerca);

        nivel1 = new JMenuItem("Nivel1");
     
        nivel2 = new JMenuItem("Nivel2");
        
        btncomen.setBounds(155, 10, 125, 30);
        nivel1.addActionListener(this);
        nivel2.addActionListener(this);
        subayuda.addActionListener(this);
       
        subpuntuaciones.addActionListener(this);
        subacerca.addActionListener(this);
        btncomen.addActionListener(this);
        btncomen.setFont(letra);
         add(btncomen);
        setVisible(true);
    }

    public static void main(String[] args) {

        new JMenup("FacSimplify");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
     

        
        if(e.getSource()==btncomen){
        dispose();
        new Ventana1 ("NIvel 1, pregunta 1.",500,500);
        }
         
        if (e.getSource() == subpuntuaciones) {
            dispose();
            new Puntuacion("Puntuaciones",600,600);

        }
        if (e.getSource() == subpuntuaciones) {
            dispose();
            new Puntuacion("Puntuaciones",600,600);

        }
        if (e.getSource() == subpuntuaciones) {
            dispose();
            new Puntuacion("Puntuaciones",600,600);

        }
    }
}
