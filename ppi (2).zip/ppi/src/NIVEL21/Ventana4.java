package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.WindowConstants;

public class Ventana4 extends JFrame implements ActionListener, MouseListener {

    String ruta = "/imagenes/";
    JRadioButton rdbtnp1, rdbtnp2, rdbtnp3, rdbtnp4;
    JLabel lbl1, lbl2;
    JButton btnOk;
    ButtonGroup group1;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana4(String titulo, int ancho, int alto) {
 this.setResizable(false);
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);

        lbl1 = new JLabel("En la expresión 2x+2y, ¿cuál");
        lbl1.setFont(letra2);
        lbl2 = new JLabel("es el factor en común?");
        lbl2.setFont(letra2);

        rdbtnp1 = new JRadioButton("x");
        rdbtnp1.setFont(letra);
        rdbtnp2 = new JRadioButton("y");
        rdbtnp2.setFont(letra);
        rdbtnp3 = new JRadioButton("4");
        rdbtnp3.setFont(letra);
        rdbtnp4 = new JRadioButton("2 ");
        rdbtnp4.setFont(letra);

        btnOk = new JButton("Ok");
        btnOk.setFont(letra);

        lbl1.setBounds(10, -280, 450, 600);
                lbl2.setBounds(10, -240, 400, 600);
        rdbtnp1.setBounds(100, 100, 50, 30);
        rdbtnp2.setBounds(100, 140, 50, 30);
        rdbtnp3.setBounds(100, 180, 50, 30);
        rdbtnp4.setBounds(100, 220, 50, 30);

        btnOk.setBounds(90, 270, 80, 30);

        group1 = new ButtonGroup();
        group1.add(rdbtnp1);
        group1.add(rdbtnp2);
        group1.add(rdbtnp3);
        group1.add(rdbtnp4);

        btnOk.addActionListener(this);

        add(lbl1);
                add(lbl2);
        add(rdbtnp1);
        add(rdbtnp2);
        add(rdbtnp3);
        add(rdbtnp4);
        add(btnOk);

        setVisible(true);
    }

    public void setVisible() {

        if (rdbtnp4.isSelected() && !(rdbtnp1.isSelected())
                && !(rdbtnp2.isSelected()) && !(rdbtnp3.isSelected())) {

            btnOk.setVisible(false);
            Datos.setContador(10);
            Puntuacion.preg4 = 10;
        } else {

            btnOk.setVisible(false);
            Datos.setErrores(10);
            Puntuacion.preg4 = 0;
        }

    }

    public static void main(String[] args) {
        new Ventana4("Nivel 1,pregunta 4 ", 500, 400);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnOk) {
            setVisible();
            dispose();
            new Ventana5("NIvel  1, Pregunta 5. ", 500, 400);
        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
