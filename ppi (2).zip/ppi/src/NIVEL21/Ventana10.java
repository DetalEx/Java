package NIVEL21;

import Seguridad.Ranking;
import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Ventana10 extends JFrame implements ActionListener {

    String ruta = "/imagenes/";
    JComboBox cbopregunta1;
    Object opciones[] = {"Seleccione", "(2x+6y)^2", "(16x+3y)^2", "(2x-6x)^2", "(4x+3y)^2"};
    JButton btnok;
    JLabel lblpregunta, lblpregunta1;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana10(String titulo, int ancho, int alto) {
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);



        cbopregunta1 = new JComboBox(opciones);
        lblpregunta = new JLabel("Al factorizar 4x^2+24xy+36y^2 ¿cuál sería ");
        lblpregunta1 = new JLabel("el resultado? ");
 this.setResizable(false);
        btnok = new JButton("Ok");
       
        lblpregunta.setBounds(10, 10, 700, 30);
        lblpregunta1.setBounds(10, 50, 600, 30);
        cbopregunta1.setBounds(10, 100, 200, 30);
        btnok.setBounds(300, 100, 80, 30);
       
        lblpregunta.setFont(letra2);
        lblpregunta1.setFont(letra2);
        cbopregunta1.setFont(letra2);
        btnok.setFont(letra2);
       
        add(btnok);
        add(lblpregunta);
        add(lblpregunta1);
        add(cbopregunta1);
       
        btnok.addActionListener(this);
       

        setVisible(true);

    }

    public void setValidar() {

        if (cbopregunta1.getSelectedItem().toString().equals("(2x+6y)^2")) {
            btnok.setVisible(false);
            Datos.setContador(10);
            Puntuacion.preg10 = 10;
        } else {
            btnok.setVisible(false);
            Datos.setErrores(10);
            Puntuacion.preg10 = 0;
        }
    }

    public static void main(String[] args) {
        new Ventana10("Nivel 2, pregunta 5.", 400, 400);
    }

    @Override
    public void actionPerformed(ActionEvent boton) {
        if (boton.getSource() == btnok) {
            setValidar();
            dispose();

            new JMenup("Menú");
        }

    }
}
