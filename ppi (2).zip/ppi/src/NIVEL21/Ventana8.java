
package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.WindowConstants;

public class Ventana8 extends JFrame implements ActionListener{
String ruta = "/imagenes/";
    JLabel lblop1,lblop2;
    JRadioButton rd1, rd2;
    JButton btnok;
    ButtonGroup grupop1;
   Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);
        
    
    public Ventana8(String titulo, int ancho, int alto) {
        this.setResizable(false);
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
       ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);
        
        //instancias
        lblop1= new JLabel ("¿El caso 2x+4x+6 es un trinomio cuadrado");
        lblop1.setFont(letra2);
        lblop2= new JLabel ("perfecto?");
        lblop2.setFont(letra2);
        rd1= new JRadioButton("Sí");
        rd1.setFont(letra);
        rd2= new JRadioButton("No");
        rd2.setFont(letra);
        
        grupop1= new ButtonGroup();
        btnok = new JButton("Ok");
        btnok.setFont(letra);
     
        lblop1.setBounds(10, 20, 600, 30);
        lblop2.setBounds(10, 60, 500, 30);
        rd1.setBounds(30, 120, 100, 30);
        rd2.setBounds(30, 170, 100, 30);
        
        btnok.setBounds(40, 220, 80, 30);
       
        
        grupop1.add(rd1);
        grupop1.add(rd2);
        
        
        
        add(btnok);
        add(lblop1);
        add(lblop2);
        add(rd1);
        add(rd2);
        
        btnok.addActionListener(this);
       
        setVisible(true);
        
        
    }
    public void setValidar(){
        if(rd2.isSelected()&& !(rd1.isSelected())){
            Datos.setContador(10);
                         

            btnok.setVisible(false);
            Puntuacion.preg8=10;
        } else{
        Datos.setErrores(10);
         btnok.setVisible(false);
         Puntuacion.preg8=0;
        }
        
    
    }

    public static void main(String[] args) {
        new Ventana8("Nivel 2, pregunta 3", 500, 400);
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
       if (e.getSource() == btnok) {
          setValidar();
          dispose();
          new Ventana9 ("NIvel  2, pregunta 4", 500, 400);
            }
     
    }
}


