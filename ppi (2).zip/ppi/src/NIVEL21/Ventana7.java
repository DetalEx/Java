package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Ventana7 extends JFrame implements ActionListener {

    String ruta = "/imagenes/";
    JCheckBox ckop1, ckop2, ckop3, ckop4;
    JLabel lblpregunta, lbop2, lbop3, lblpregunta2;
    JButton btnok;
    int contador = 0;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana7(String titulo, int ancho, int alto) {
         this.setResizable(false);
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);
        lblpregunta = new JLabel("¿Cuál es la factorización del trinomio cuadrado");
        lblpregunta2 = new JLabel(" perfecto: 4x^2-12x+9?");

        ckop1 = new JCheckBox("(2x-3)^2");
        ckop2 = new JCheckBox("(a-b)^2");
        ckop3 = new JCheckBox("(a+b)^2");
        ckop4 = new JCheckBox("(2x+3)^2");
        btnok = new JButton("Ok");

        lblpregunta.setBounds(10, 8, 600, 30);
        lblpregunta.setFont(letra2);
        lblpregunta2.setBounds(10, 50, 450, 30);
        lblpregunta2.setFont(letra2);
        ckop1.setBounds(65, 100, 150, 30);
        ckop1.setFont(letra);
        ckop2.setBounds(65, 140, 150, 30);
        ckop2.setFont(letra);
        ckop3.setBounds(65, 180, 150, 30);
        ckop3.setFont(letra);
        ckop4.setBounds(65, 220, 150, 30);
        ckop4.setFont(letra);
        btnok.setBounds(95, 260, 80, 30);
        btnok.setFont(letra);

        btnok.addActionListener(this);
       

        add(lblpregunta);
        add(lblpregunta2);
        add(ckop1);
        add(ckop2);
        add(ckop3);
        add(ckop4);
        add(btnok);

        setVisible(true);

    }

    public void setValidar() {

        if ((ckop1.isSelected()) && (ckop2.isSelected())
                && (!ckop3.isSelected()) && (!ckop4.isSelected())) {

            Datos.setContador(10);
            Puntuacion.preg7 = 10;

            btnok.setVisible(false);
        } else {
            Datos.setErrores(10);
            Puntuacion.preg7 = 0;

            btnok.setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Ventana7("NIvel 2, pregunta 2", 500, 400);

    }

    @Override
    public void actionPerformed(ActionEvent boton) {
        if (boton.getSource() == btnok) {
           
                setValidar();
                dispose();
                new Ventana8("NIvel  2, pregunta 3", 500, 400);
           
        }

    }

}
