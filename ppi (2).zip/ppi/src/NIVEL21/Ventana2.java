package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import com.sun.org.apache.xerces.internal.xs.PSVIProvider;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.WindowConstants;

public class Ventana2 extends JFrame implements ActionListener , MouseListener{
String ruta = "/imagenes/";
    JRadioButton rdbtnop1, rdbtnop2, rdbtnop3, rdbtnop4;
    JLabel lblpregunta1,lblpregunta2;
    JButton btnok;
    ButtonGroup grupop1;
    int contador=0;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public  Ventana2(String titulo, int ancho, int alto) {
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
       ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
 this.setResizable(false);
        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);

        //paso 2 crear las instancias
        lblpregunta1 = new JLabel("¿En un caso de factor común debo escoger la");
         lblpregunta1.setFont(letra2);
             lblpregunta2 = new JLabel   ( " letra repetida con menor exponente?");
              lblpregunta2.setFont(letra2);
        rdbtnop1 = new JRadioButton("Sí");
         rdbtnop1.setFont(letra);
        rdbtnop2 = new JRadioButton("No");
         rdbtnop2.setFont(letra);
       
        
        grupop1 = new ButtonGroup();
        btnok = new JButton("Ok");
         btnok.setFont(letra);
       

        lblpregunta1.setBounds(10, 20, 600, 30);
        lblpregunta2.setBounds(10, 60, 600, 30);
        
        rdbtnop1.setBounds(190, 110, 120, 30);
        rdbtnop2.setBounds(190, 150, 120, 30);
        
        btnok.setBounds(210, 200, 80, 30);
       

        grupop1.add(rdbtnop1);
        grupop1.add(rdbtnop2);
       
       

        add(btnok);
        add(lblpregunta2);
        add(lblpregunta1);
        add(rdbtnop1);
        add(rdbtnop2);
       

        btnok.addActionListener(this);
        
        setVisible(true);

    }
    public static void main(String[] args) {
        new Ventana2 (" Nivel 1 Pregunta 2", 550, 500);
    }
    public void setValidar (){
    if (rdbtnop1. isSelected()&&!(rdbtnop2. isSelected())){
        
       
        btnok.setVisible(false);
        Datos.setContador(10);
         Puntuacion.preg2=10;
    }else{
    
        btnok.setVisible(false);
        Datos.setErrores(10);
         Puntuacion.preg2=0;
    }
    
    }
    @Override
    public void actionPerformed(ActionEvent boton) {
        if(boton.getSource()==btnok){
       setValidar();
         dispose();
       new Ventana3("Nivel 1,pregunta 3",500,400);
        }
  
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        }

    @Override
    public void mouseReleased(MouseEvent e) {
       }

    @Override
    public void mouseEntered(MouseEvent e) {
        }

    @Override
    public void mouseExited(MouseEvent e) {
     }
}