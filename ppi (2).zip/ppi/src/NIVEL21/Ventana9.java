package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Ventana9 extends JFrame implements ActionListener {

    String ruta = "/imagenes/";
    JCheckBox ckop1, ckop2, ckop3, ckop4;
    JLabel lblpregunta, lbop2, lbop3;
    JButton btnok;
    int contador = 0;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana9(String titulo, int ancho, int alto) {
        this.setResizable(false);
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);
        lblpregunta = new JLabel("¿Qué trinomios son cuadrados perfectos?");
        lblpregunta.setFont(letra2);

        ckop1 = new JCheckBox("16a^2-20a+25");
        ckop2 = new JCheckBox("(81a^2+90a+100y");
        ckop3 = new JCheckBox("49x^2+84xy+36y^2");
        ckop4 = new JCheckBox("9x^2+48x+64");
        btnok = new JButton("Ok");
        ckop1.setFont(letra);
        ckop2.setFont(letra);
        ckop3.setFont(letra);
        ckop4.setFont(letra);
        btnok.setFont(letra);
        lblpregunta.setBounds(10, 15, 600, 30);
        ckop1.setBounds(10, 60, 280, 30);
        ckop2.setBounds(10, 100, 280, 30);
        ckop3.setBounds(10, 140, 280, 30);
        ckop4.setBounds(10, 180, 280, 30);

        btnok.setBounds(80, 220, 80, 30);
        btnok.addActionListener(this);

        add(lblpregunta);
        add(ckop1);
        add(ckop2);
        add(ckop3);
        add(ckop4);
        add(btnok);


        setVisible(true);

    }

    public void setValidar() {

        if ((ckop3.isSelected()) && (ckop4.isSelected())
                && (!ckop2.isSelected()) && (!ckop1.isSelected())) {

            btnok.setVisible(false);
            Datos.setContador(10);
            Puntuacion.preg9 = 10;

        } else {
            Datos.setErrores(10);
            btnok.setVisible(false);
            Puntuacion.preg9 = 0;

        }

    }

    public static void main(String[] args) {
        new Ventana9("NIvel  2, pregunta 4", 500, 400);

    }

    @Override
    public void actionPerformed(ActionEvent boton) {
        if (boton.getSource() == btnok) {

            setValidar();
            dispose();
            new Ventana10(" Nivel 2, pregunta 5", 400, 400);

        }

    }
}
