package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.WindowConstants;

public class Ventana5 extends JFrame implements ActionListener {
 
    String ruta = "/imagenes/";
    JRadioButton rdbtnp1, rdbtnp2, rdbtnp3, rdbtnp4;
    JLabel lbl1, lbl2, lbl3, lbl4, lbl5, lblimagen;
    JButton btnOk;
    ButtonGroup group1;
    ImageIcon factor;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana5(String titulo, int ancho, int alto) {
this.setResizable(false);
        setLayout(null);
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(this);
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);

        lbl1 = new JLabel("¿Es esto factor común?");
        lbl1.setFont(letra2);
        

        factor = new ImageIcon(getClass().getResource(ruta + "Factor_comun.png"));

        rdbtnp1 = new JRadioButton("Tal vez");
        rdbtnp1.setFont(letra);
        rdbtnp2 = new JRadioButton("No");
        rdbtnp2.setFont(letra);
        rdbtnp3 = new JRadioButton("Eso no es factorización");
        rdbtnp3.setFont(letra);
        rdbtnp4 = new JRadioButton("Sí");
        rdbtnp4.setFont(letra);
        lblimagen = new JLabel(factor);

        btnOk = new JButton("Ok");
        btnOk.setFont(letra);

        lbl1.setBounds(30, 20, 300, 30);
        lblimagen.setBounds(-10, 55, 400, 50);
        rdbtnp1.setBounds(30, 120, 330, 30);
        rdbtnp2.setBounds(30, 160, 330, 30);
        rdbtnp3.setBounds(30, 200, 330, 30);
        rdbtnp4.setBounds(30, 240, 330, 30);
        btnOk.setBounds(130, 280, 80, 30);
        group1 = new ButtonGroup();
        group1.add(rdbtnp1);
        group1.add(rdbtnp2);
        group1.add(rdbtnp3);
        group1.add(rdbtnp4);
        btnOk.addActionListener(this);

        add(lbl1);
        add(rdbtnp1);
        add(rdbtnp2);
        add(rdbtnp3);
        add(rdbtnp4);
        add(btnOk);
        add(lblimagen);

        add(lblimagen);

        setVisible(true);
    }

    public void setValidar() {

        if (rdbtnp4.isSelected()) {
            Datos.setContador(10);
            Puntuacion.preg5 = 10;
            btnOk.setVisible(false);
        } else {
            btnOk.setVisible(false);
            Datos.setErrores(10);
            Puntuacion.preg5 = 0;
        }

    }

    public static void main(String[] args) {
        new Ventana5("Nivel 1,pregunta 5. ", 500, 400);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnOk) {
            setValidar();
            dispose();
            new Ventana6("NIvel  2, Pregunta 1.", 500, 400);
        }

    }

}
