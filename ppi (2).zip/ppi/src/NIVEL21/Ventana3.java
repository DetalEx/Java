package NIVEL21;

import Utilidades.Datos;
import Utilidades.Puntos;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Ventana3 extends JFrame implements ActionListener{
//paso 1 declaracion variables

    String ruta = "/imagenes/";
    JCheckBox ckop1, ckop2, ckop3, ckop4;
    JLabel lblpreg, lblpreg2;
    JButton btnok, btnresp;
    int contador = 0;
    Font letra = new Font("Times New Roman", 1, 30);
    Font letra2 = new Font("Times New Roman", 1, 30);

    public Ventana3(String Titulo, int ancho, int alto) {
 this.setResizable(false);
        setLayout(null); //evitar distribuciones automaticas
        setTitle(Titulo);//titulo
        setSize(ancho, alto);//tamaño formularios
        setLocationRelativeTo(this);//centrado automatico
        //paso 2 crear instancias
        //de la clase padre(base)
        ImageIcon img = new ImageIcon(getClass().getResource(ruta + "fondoma.png"));
        setSize(img.getIconWidth(), img.getIconHeight());//tamaño formularios
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

        JLayeredPane layered = new JLayeredPane();// objeto para colocar imagen de fondo
        ((JPanel) getContentPane()).setOpaque(false);
        JLabel fondo = new JLabel(img);
//fondo.setBounds(200,0,248,238);
        fondo.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
// pegamos el fondo al LayerPane(.add)
        getLayeredPane().add(fondo, JLayeredPane.FRAME_CONTENT_LAYER);
        lblpreg = new JLabel("Seleccione las opciones donde se");
        lblpreg.setFont(letra2);

        lblpreg2 = new JLabel("pueda aplicar factor común");
        lblpreg2.setFont(letra2);

        ckop1 = new JCheckBox("2x^2+6x^2");
        ckop1.setFont(letra);
        ckop2 = new JCheckBox("3x^2-1");
        ckop2.setFont(letra);
        ckop3 = new JCheckBox("x+(-4x)");
        ckop3.setFont(letra);
        ckop4 = new JCheckBox("9+5x^2");
        ckop4.setFont(letra);
        btnok = new JButton("Ok");
        btnok.setFont(letra);

        //paso 3 colocar coordenadas y tamaños
        lblpreg.setBounds(10, 20, 450, 30);
        lblpreg2.setBounds(10, 60, 450, 30);

        ckop1.setBounds(110, 110, 170, 30);
        
        ckop2.setBounds(110, 150, 170, 30);
       
        ckop3.setBounds(110, 190, 170, 30);
       
        ckop4.setBounds(110, 230, 170, 30);
        
        btnok.setBounds(160, 270, 80, 30);

        btnok.addActionListener(this);

        //paso 4 colocar JPanel
        add(lblpreg);
        add(ckop1);
        add(ckop2);
        add(ckop3);
        add(ckop4);
        add(lblpreg2);
         add(btnok);

        setVisible(true);

    }

    public void setValidar() {
        if ((ckop1.isSelected())
                && (ckop3.isSelected())
                && (!ckop2.isSelected())
                && (!ckop4.isSelected())) {
            btnok.setVisible(false);
            Datos.setContador(10);
            Puntuacion.preg3 = 10;
        } else {
            btnok.setVisible(false);
            Datos.setErrores(10);
            Puntuacion.preg3 = 0;
        }
    }

    public static void main(String[] args) {

        new Ventana3("nivel 1, pregunta 3", 500, 400);
    }

    @Override
    public void actionPerformed(ActionEvent boton) {
        if (boton.getSource() == btnok) {
            
                setValidar();
                dispose();
                new Ventana4("NIvel  1, Pregunta 4.", 500, 400);
            
        }
    }

    
}
