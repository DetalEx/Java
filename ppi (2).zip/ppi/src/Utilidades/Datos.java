
package Utilidades;

import javax.swing.JOptionPane;

public class Datos {
private static int contador,errores;
private static String nombre;

    public static int getContador() {
        
        return contador;
    }

    public static void setContador(int puntos) {
       
        contador+= puntos;
    }
 public static void setBorrarpuntos() {
        contador= 0;
        errores=0;
    }

    public static int getErrores() {
        return errores;
    }

    public static void setErrores(int error) {
       errores += error;
    }

    public static String getNombre() {
        return nombre;
    }

    public static void setNombre(String nombre) {
        Datos.nombre = nombre;
    }
    
    public static void main(String[] args) {

        // public static String getPregunta(int posicion){
        String respuesta;
        String preguntas[] = new String[4];
        preguntas[0] = "La interface que permita programar eventos sobre el Mouse:";
        preguntas[1] = "La interface que permita programar eventos sobre el Teclado:";
        preguntas[2] = "La interface que permita programar eventos generales:";
        preguntas[3] = "Generalmente todas las interfaces aplicadas a la vista reciben "
                + "el parametro:";

//return  preguntas[posicion];
//} 
//public static String getOpcion(int pos){
        String opcion[] = new String[4];
        opcion[0] = "ActionListener";
        opcion[1] = "MouseListener";
        opcion[2] = "KeyListener";
        opcion[3] = "ActionEvent";

//return opcion[pos];
//}  
        //public static String getSolucion(int posicion){
        String solucion[] = new String[4];
        solucion[0] = "MouseListener";
        solucion[1] = "KeyListener";
        solucion[2] = "ActionListener";
        solucion[3] = "ActionEvent";

//return  solucion[posicion];
//}   
        for (int i = 0; i < preguntas.length; i++) {
            System.out.println("La pregunta es:" + preguntas[i]);
            for (int j = 0; j < opcion.length; j++) {

                System.out.println("su opcion" + (j ) + " es:" + opcion[j]);
            }
            System.out.println("solucion es:" + solucion[i]);
        }
String tabla = "<html><body><table><tr><td>Pregunta</td><td>Op1</td><td>Op2</td><td>Op3</td><td>Op4</><td>Respuesta</>";
    for (int k = 0;
    k< preguntas.length ;
    k

    
        ++) {
            System.out.println(preguntas[k] + "" + opcion[k]);
        tabla += "<tr><td>" + preguntas[k] + "</td><td>"
                + opcion[k] + "</td><td>" + opcion[k] + "</td><td>" + opcion[k]
                + "</td> <td>" + opcion[k]
                + "</td> <td>" + solucion[k]
                + "</td></tr>";
    }
    tabla += "</table></body></html>" ;

    JOptionPane.showMessageDialog (null, tabla);
    }
    

}
