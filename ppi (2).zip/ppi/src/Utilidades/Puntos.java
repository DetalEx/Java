
package Utilidades;
public class Puntos {
    private static String nombre;
    private static int aciertos, errores;

    public static String getNombre() {
        return nombre;
    }

    public static void setNombre(String Nick) {
        Puntos.nombre = Nick;
    }

    public static int getAciertos() {
        return aciertos;
    }

    public static void setAciertos(int valor) {
        aciertos+= valor;
    }

    public static int getErrores() {
        return errores;
    }

    public static void setErrores(int valor) {
        errores+= valor;
    }
    
}
